package pages.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Managed;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Login {

    @Managed
    private WebDriver driver;

    @Given("I navigate to the WaytoAutomation Web Table")
    public void iNavigateToTheWaytoAutomationWebTable() {
        driver.get("https://www.way2automation.com/angularjs-protractor/webtables/");
    }

    @And("I validate that I am on the User List Table")
    public void iValidateThatIAmOnTheUserListTable() {
        // Find an element unique to the User List Table page
        WebElement userListTableElement = driver.findElement(By.xpath("//tr[contains(@class, 'smart-table-header-row')]"));
        WebElement AddUser = driver.findElement(By.xpath("//thead/tr[2]/td[1]/button[1]"));

        // Check if the element is present, which indicates that we are on the User List Table page
        if (userListTableElement.isDisplayed() && AddUser.isDisplayed()) {
            System.out.println("You are on the User List Table page.");
        } else {
            System.out.println("You are not on the User List Table page.");
        }

    }

    @When("I click Add User button")
    public void iClickAddUserButton() {
        WebElement AddUser = driver.findElement(By.xpath("//thead/tr[2]/td[1]/button[1]"));
        AddUser.click();
    }


    @And("I am able to Add Users with the following details")
    public void iAmAbleToAddUsersWithTheFollowingDetails() {
        // Navigate to the URL
        driver.get("https://www.way2automation.com/angularjs-protractor/webtables/");

        // Define the data arrays
        String[] firstNames = {"FName1", "FName2"};
        String[] lastNames = {"LName1", "LName2"};
        String[] userNames = {"User1", "User2"};
        String[] passwords = {"Pass1", "Pass2"};
        String[] customers = {"Company AAA", "Company BBB"};
        String[] roles = {"Admin", "Customer"};
        String[] emails = {"admin@gmail.com", "customer@gmail.com"};
        String[] cellPhones = {"082555", "083444"};

        // Find the "Add User" button
        WebElement addUserButton = driver.findElement(By.xpath("//button[contains(text(), 'Add User')]"));

        // Loop through the data arrays and add each entry to the web table
        for (int i = 0; i < firstNames.length; i++) {
            // Click the "Add User" button to open the form
            addUserButton.click();

            // Find the form fields
            WebElement firstNameField = driver.findElement(By.name("FirstName"));
            WebElement lastNameField = driver.findElement(By.name("LastName"));
            WebElement userNameField = driver.findElement(By.name("UserName"));
            WebElement passwordField = driver.findElement(By.name("Password"));
            WebElement customerRadio = driver.findElement(By.xpath("//input[@value='15']"));
            WebElement roleDropdown = driver.findElement(By.name("RoleId"));
            WebElement emailField = driver.findElement(By.name("Email"));
            WebElement cellPhoneField = driver.findElement(By.name("Mobilephone"));
            WebElement saveButton = driver.findElement(By.xpath("//button[contains(text(), 'Save')]"));

            // Fill in the form fields with the data for the current entry
            firstNameField.sendKeys(firstNames[i]);
            lastNameField.sendKeys(lastNames[i]);
            userNameField.sendKeys(userNames[i]);
            passwordField.sendKeys(passwords[i]);
            customerRadio.click();
            new Select(roleDropdown).selectByVisibleText(roles[i]);
            emailField.sendKeys(emails[i]);
            cellPhoneField.sendKeys(cellPhones[i]);

            // Click the "Save" button to add the current entry
            saveButton.click();

            // Wait for the success message to be displayed
            // (You can use WebDriverWait here, similar to the previous example, if needed)
            try {
                Thread.sleep(1000); // Give it a moment to display the success message (not recommended in production code)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Close the browser
        driver.quit();

    }

}
