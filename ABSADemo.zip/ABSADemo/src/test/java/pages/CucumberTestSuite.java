package pages;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.core.guice.Injectors;
import net.thucydides.core.reports.html.HtmlAggregateStoryReporter;
import net.thucydides.core.webdriver.Configuration;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.IOException;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        plugin = {"pretty"},
        features = "src/test/resources/features/SwagLabs/"
)
public class CucumberTestSuite {

    @AfterClass
    public static void complete() {
        aggregateReportResults();
    }

    private static void aggregateReportResults() {

        net.thucydides.core.webdriver.Configuration systemConfiguration = Injectors.getInjector().getInstance(Configuration.class);
        File reportOutputDirectory = systemConfiguration.getOutputDirectory();

        HtmlAggregateStoryReporter reporter = new HtmlAggregateStoryReporter("CoreRegressionTest");
        reporter.setSourceDirectory(reportOutputDirectory);
        reporter.setOutputDirectory(reportOutputDirectory);
        try {
            reporter.generateReportsForTestResultsFrom(reportOutputDirectory);
        } catch (IOException e) {
            System.out.println(String.format("Unable to aggregate results for test: ", e));
        }
        System.out.println(String.format("[console]Aggregated test results are available here: file://" + "%s" + "index.html", reportOutputDirectory.toURI().getSchemeSpecificPart()));

    }
}