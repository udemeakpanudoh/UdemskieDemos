import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.testng.annotations.Test;

import java.io.IOException;

public class DogSubBreedRandomImage {
    @Test
    public void test_01() {
        String apiUrl = "https://dog.ceo/api/breeds/image/random";

        try {
            OkHttpClient httpClient = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(apiUrl)
                    .get()
                    .build();

            Response response = httpClient.newCall(request).execute();
            String jsonResponse = response.body().string();

            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonNode = mapper.readTree(jsonResponse);
            String imageUrl = jsonNode.get("message").asText();

            // Modify the image URL to include the sub-breed "golden"
            String goldenSubBreedUrl = imageUrl.replace("breeds", "breed/golden");

            System.out.println("Random image/link for 'golden' sub-breed:");
            System.out.println(goldenSubBreedUrl);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}