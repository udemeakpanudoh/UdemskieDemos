import io.restassured.response.Response;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Iterator;

public class dogBreeds_GET {

    @Test
    public void test_01() {
        String baseUrl = "https://dog.ceo/api/";
        Response response = get(baseUrl + "breeds/list/all");
        System.out.println(response.asString());
        String jsonResponse = (response.asString());

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonNode = mapper.readTree(jsonResponse);
            JsonNode messageNode = jsonNode.get("message");

            if (messageNode != null && messageNode.isObject()) {
                Iterator<String> breedNames = messageNode.fieldNames();
                System.out.println("Dog Breeds:");
                while (breedNames.hasNext()) {
                    String breedName = breedNames.next();
                    System.out.println("- " + breedName);
                }
            } else {
                System.out.println("No dog breeds found in the response.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}