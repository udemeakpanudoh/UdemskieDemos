import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.Iterator;

public class DogBreedsAPIRequest {
    @Test
    public void test_01() {

        String apiUrl = "https://dog.ceo/api/breeds/list/all";

        try {
            OkHttpClient httpClient = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(apiUrl)
                    .get()
                    .build();

            Response response = httpClient.newCall(request).execute();
            String jsonResponse = response.body().string();

            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonNode = mapper.readTree(jsonResponse);
            JsonNode messageNode = jsonNode.get("message");

            if (messageNode != null && messageNode.isObject()) {
                JsonNode retrieverNode = messageNode.get("retriever");
                if (retrieverNode != null && retrieverNode.isArray()) {
                    System.out.println("Sub-breeds of 'retriever':");
                    Iterator<JsonNode> subBreeds = retrieverNode.elements();
                    while (subBreeds.hasNext()) {
                        String subBreed = subBreeds.next().asText();
                        System.out.println("- " + subBreed);
                    }
                } else {
                    System.out.println("No sub-breeds found for 'retriever'.");
                }
            } else {
                System.out.println("No dog breeds found in the response.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
